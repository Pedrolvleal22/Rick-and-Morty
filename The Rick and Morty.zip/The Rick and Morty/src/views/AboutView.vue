<template>
  <div class="about">
    Aluno: Pedro Lucas Vasconcelos Leal <br>
    RA: 1968204 <br>
    Curso: Análise e Desenvolvimento de Sistemas<br>
    Turma: 3C<br>
    Unimar<br>
  </div>
</template>